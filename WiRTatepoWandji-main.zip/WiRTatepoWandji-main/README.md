# WiRTatepoWandji
Repository für Wissenschaftliches Rechnen - Tatepo und Wandji.

In diesem Repository sind Github Pages aktiviert. Dateien, die im docs-Verzeichnis liegen, wie 
zum Beispiele kommentare.html, können wir im Browser so sehen:

https://vrlab-hskl.github.io/WiRTatepoWandji/kommentare.html

Unsere Simulation Html Datei ist unter des folgenden Link sichtbar
https://vrlab-hskl.github.io/WiRTatepoWandji/SimulationsKrankheit.html
